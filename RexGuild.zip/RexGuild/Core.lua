-- ============================================================
--  RexGuild – Core.lua (FINAL CLEAN STABLE)
-- ============================================================

local ADDON_NAME = "RexGuild"
local RexGuild = LibStub("AceAddon-3.0"):NewAddon(ADDON_NAME, "AceEvent-3.0", "AceComm-3.0")
_G[ADDON_NAME] = RexGuild

-- ── Default SavedVariables ──────────────────────────────────
local DB_DEFAULTS = {
    keys   = {},
    groups = {},
    raids  = {},
    roles  = {}, -- manuelle Rollen
	players = {}, -- 🔥 NEU (für GS & später mehr)
}

-- ── Addon Lifecycle ─────────────────────────────────────────
function RexGuild:OnInitialize()

    if not RexGuildDB then
        RexGuildDB = CopyTable(DB_DEFAULTS)
    else
        for k, v in pairs(DB_DEFAULTS) do
            if RexGuildDB[k] == nil then
                RexGuildDB[k] = v
            end
        end
    end

    self.db = RexGuildDB

    print("|cFF9370DBRexGuild|r loaded. Type /rg")
end

function RexGuild:OnEnable()
    self:RegisterEvent("PLAYER_ENTERING_WORLD", "OnPlayerEnteringWorld")
    self:RegisterEvent("GROUP_ROSTER_UPDATE", "OnGroupRosterUpdate")
    self:RegisterComm(ADDON_NAME, "OnCommReceived")
end

function RexGuild:OnDisable()
    self:UnregisterAllEvents()
    self:UnregisterAllComm()
end

-- ── Events ──────────────────────────────────────────────────
function RexGuild:OnPlayerEnteringWorld()
    C_Timer.After(2, function()

        -- 🔥 GS setzen
        self:UpdateMyGS()

        if RexGuild.Sync then
            RexGuild.Sync:BroadcastMyRole()
        end

        -- 🔥 INFO IM CHAT (NEU)
        print("|cFF9370DBRexGuild|r geöffnet mit |cFF00CCFF/rg|r")

    end)
end

function RexGuild:OnGroupRosterUpdate()
    if self.UI_Main then
        self.UI_Main:Refresh()
    end
end
-- ── Comm ────────────────────────────────────────────────────
function RexGuild:OnCommReceived(prefix, message, distribution, sender)
    if sender == UnitName("player") then return end
    if self.Sync then
        self.Sync:HandleIncoming(message, sender)
    end
end

-- ── Helpers ─────────────────────────────────────────────────
function RexGuild:GetMyName()
    return UnitName("player")
end

-- 🔥 GS SYSTEM (NEU)
function RexGuild:UpdateMyGS()
    self.db = self.db or {}
    self.db.players = self.db.players or {}

    local name = self:GetMyName()

    -- 🔥 SAFE API
    local avg, equipped = GetAverageItemLevel()
    local gs = math.floor(equipped or avg or 0)

    self.db.players[name] = self.db.players[name] or {}
    self.db.players[name].gs = gs

    return gs
end

-- 🔥 FINAL ROLE SYSTEM (ONLY MANUAL)
function RexGuild:GetMyRole()
    if not self.db or not self.db.roles then
        return "DPS"
    end

    local role = self.db.roles[self:GetMyName()] or "DPS"

    if role == "HEALER" then role = "HEAL" end
    if role == "DAMAGER" then role = "DPS" end

    return role
end

function RexGuild:SetMyRole(role)

    if not role then return end

    self.db = self.db or {}
    self.db.roles = self.db.roles or {}

    if role == "HEALER" then role = "HEAL" end
    if role == "DAMAGER" then role = "DPS" end

    self.db.roles[self:GetMyName()] = role

    -- 🔥 GS direkt mit updaten (WICHTIG)
    self:UpdateMyGS()

    -- 🔥 Sync
    if self.Sync then
        self.Sync:BroadcastMyRole()
    end

    -- 🔥 UI UPDATE
    if self.UI_Groups then
        self.UI_Groups:Refresh()
    end
end
-- ── Slash Command ───────────────────────────────────────────
SLASH_REXGUILD1 = "/rg"
SlashCmdList["REXGUILD"] = function(msg)
    if RexGuild.UI_Main then
        RexGuild.UI_Main:Toggle()
    end
end