-- ============================================================
--  RexGuild – UI/UI_Raids.lua
-- ============================================================

local RexGuild = _G["RexGuild"]
RexGuild.UI_Raids = {}
local UIR = RexGuild.UI_Raids

local raidRows = {}

-- Blizzard Role Icons (gleich wie in UI_Groups)
local ROLE_ICONS = {
    TANK    = "|TInterface\\LFGFrame\\UI-LFG-ICON-PORTRAITROLES:16:16:0:0:64:64:0:19:22:41|t",
    HEALER  = "|TInterface\\LFGFrame\\UI-LFG-ICON-PORTRAITROLES:16:16:0:0:64:64:20:39:1:20|t",
    DAMAGER = "|TInterface\\LFGFrame\\UI-LFG-ICON-PORTRAITROLES:16:16:0:0:64:64:20:39:22:41|t",
}

-- ────────────────────────────────────────────────────────────
-- INIT
-- ────────────────────────────────────────────────────────────
function UIR:Init(parent)
    self.parent = parent

    local header = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    header:SetPoint("TOPLEFT", parent, "TOPLEFT", 10, -10)
    header:SetText("Raid Planer")

    local createBtn = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    createBtn:SetSize(130, 26)
    createBtn:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -10, -10)
    createBtn:SetText("Raid erstellen")
    createBtn:SetScript("OnClick", function() UIR:ShowCreateDialog() end)

    local sf = CreateFrame("ScrollFrame", nil, parent, "UIPanelScrollFrameTemplate")
    sf:SetPoint("TOPLEFT",     parent, "TOPLEFT",     10, -44)
    sf:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", -30, 10)
    self.scrollFrame = sf

    local content = CreateFrame("Frame", nil, sf)
    content:SetSize(sf:GetWidth() or 600, 1)
    sf:SetScrollChild(content)
    self.content = content

    UIR:Refresh()
end

-- ────────────────────────────────────────────────────────────
-- REFRESH
-- ────────────────────────────────────────────────────────────
function UIR:Refresh()
    if not self.content then return end

    for _, r in ipairs(raidRows) do
        if r and r.Hide then r:Hide() end
    end
    wipe(raidRows)

    local raids   = RexGuild.Raids and RexGuild.Raids:GetUpcoming() or {}
    local myName  = RexGuild:GetMyName()
    local myShort = myName:match("^([^%-]+)") or myName
    local y       = 0

    for _, raid in ipairs(raids) do
        local summary  = RexGuild.Raids:GetRosterSummary(raid.id)
        local orgShort = (raid.organizer or ""):match("^([^%-]+)") or ""
        local isOrg    = (myShort == orgShort)

        -- Mein RSVP-Status
        local myRSVP = nil
        if raid.rsvp then
            for n, e in pairs(raid.rsvp) do
                if (n:match("^([^%-]+)") or n) == myShort then
                    myRSVP = e.status
                    break
                end
            end
        end

        -- Zeilenhöhe: Titel(20) + Datum(20) + Roster(20) + Status(20) + RSVP-Buttons(28) + Org-Buttons(28) + Padding
        local ROW_H = isOrg and 148 or 118

        local row = CreateFrame("Frame", nil, self.content, "BackdropTemplate")
        row:SetSize(self.content:GetWidth() or 560, ROW_H)
        row:SetPoint("TOPLEFT", self.content, "TOPLEFT", 0, -y)
        if not row.SetBackdrop then Mixin(row, BackdropTemplateMixin) end
        row:SetBackdrop({
            bgFile   = "Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            edgeSize = 12,
            insets   = { left = 3, right = 3, top = 3, bottom = 3 },
        })
        row:SetBackdropColor(0.1, 0.08, 0.15, 0.90)

        -- ── Zeile 1: Titel ───────────────────────────────────
        local title = row:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOPLEFT", row, "TOPLEFT", 10, -10)
        title:SetText(raid.title or "Raid")

        -- ── Zeile 2: Datum / Uhrzeit / Organizer ─────────────
local dateText = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
dateText:SetPoint("TOPLEFT", row, "TOPLEFT", 10, -32)

-- 🔥 Datum sauber formatieren (TT.MM.JJJJ)
local formattedDate = raid.date or "?"

-- erkennt Format YYYY-MM-DD und wandelt um
local y, m, d = formattedDate:match("(%d+)%-(%d+)%-(%d+)")
if y and m and d then
    formattedDate = string.format("%02d.%02d.%04d", d, m, y)
end

dateText:SetText(string.format(
    "|cFFAAAAFF%s  %s|r   von: |cFFFFD100%s|r",
    formattedDate,
    raid.time or "?",
    raid.organizer or "?"
))

        -- ── Zeile 3: Roster mit Role-Icons ───────────────────
local rosterText = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
rosterText:SetPoint("TOPLEFT", row, "TOPLEFT", 10, -54)

rosterText:SetText(string.format(
    "%s %d   %s %d   %s %d          %s %d   %s %d   %s %d",
    
    -- ✅ Ready Check Icons statt Kästchen
    "|TInterface\\RaidFrame\\ReadyCheck-Ready:16|t", summary.yes or 0,
    "|TInterface\\RaidFrame\\ReadyCheck-NotReady:16|t", summary.no or 0,
    "|TInterface\\RaidFrame\\ReadyCheck-Waiting:16|t", summary.late or 0,

    -- ✅ Deine Role Icons bleiben gleich
    ROLE_ICONS.TANK,    summary.tanks   or 0,
    ROLE_ICONS.HEALER,  summary.healers or 0,
    ROLE_ICONS.DAMAGER, summary.dps     or 0
))

        -- ── Zeile 4: Mein Status ──────────────────────────────
        local statusLabel = ""

if myRSVP == "YES" then
    statusLabel = string.format(
        "|cFF00FF00%s Komme|r",
        "|TInterface\\RaidFrame\\ReadyCheck-Ready:16|t"
    )

elseif myRSVP == "NO" then
    statusLabel = string.format(
        "|cFFFF4444%s Komme nicht|r",
        "|TInterface\\RaidFrame\\ReadyCheck-NotReady:16|t"
    )

elseif myRSVP == "LATE" then
    statusLabel = string.format(
        "|cFFFFAA00%s Komme später|r",
        "|TInterface\\RaidFrame\\ReadyCheck-Waiting:16|t"
    )

else
    statusLabel = "|cFF888888– Noch nicht angemeldet|r"
end

        -- ── RSVP Buttons (Zeile 5) ────────────────────────────
        local raidID = raid.id
        local btnY   = isOrg and -98 or -88

        local yBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        yBtn:SetSize(80, 24)
        yBtn:SetPoint("TOPLEFT", row, "TOPLEFT", 10, btnY)
        yBtn:SetText("|cFF00FF00Komme|r")
        yBtn:SetScript("OnClick", function()
            RexGuild.Raids:SetRSVP(raidID, "YES")
        end)

        local nBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        nBtn:SetSize(100, 24)
        nBtn:SetPoint("LEFT", yBtn, "RIGHT", 6, 0)
        nBtn:SetText("|cFFFF4444Komme nicht|r")
        nBtn:SetScript("OnClick", function()
            RexGuild.Raids:SetRSVP(raidID, "NO")
        end)

        local lBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        lBtn:SetSize(110, 24)
        lBtn:SetPoint("LEFT", nBtn, "RIGHT", 6, 0)
        lBtn:SetText("|cFFFFAA00Komme später|r")
        lBtn:SetScript("OnClick", function()
            RexGuild.Raids:SetRSVP(raidID, "LATE")
        end)

        -- ── Organizer Buttons (Zeile 6, nur für Org) ─────────
        if isOrg then
            local inviteBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
            inviteBtn:SetSize(120, 24)
            inviteBtn:SetPoint("TOPLEFT", row, "TOPLEFT", 10, -126)
            inviteBtn:SetText("|cFF00CCFFAlle einladen|r")
            inviteBtn:SetScript("OnClick", function()
                RexGuild.Raids:InviteAll(raidID)
            end)

            local delBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
            delBtn:SetSize(90, 24)
            delBtn:SetPoint("LEFT", inviteBtn, "RIGHT", 6, 0)
            delBtn:SetText("|cFFFF4444Löschen|r")
            delBtn:SetScript("OnClick", function()
                RexGuild.Raids:Delete(raidID)
            end)
        end

        table.insert(raidRows, row)
        y = y + ROW_H + 8
    end

    if #raids == 0 then
        local empty = self.content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        empty:SetPoint("TOPLEFT", self.content, "TOPLEFT", 8, -10)
        empty:SetText("|cFF888888Noch keine Raid-Events. Klicke 'Raid erstellen'.|r")
        table.insert(raidRows, empty)
    end

    self.content:SetHeight(math.max(y, 20))
end

-- ────────────────────────────────────────────────────────────
-- CREATE DIALOG
-- ────────────────────────────────────────────────────────────
function UIR:ShowCreateDialog()
    if self.createDialog then
        self.createDialog:Show()
        return
    end

    local dlg = CreateFrame("Frame", "RexGuildRaidDlg", UIParent, "BackdropTemplate")
    dlg:SetSize(340, 240)
    dlg:SetPoint("CENTER")
    dlg:SetMovable(true)
    dlg:EnableMouse(true)
    dlg:RegisterForDrag("LeftButton")
    dlg:SetScript("OnDragStart", dlg.StartMoving)
    dlg:SetScript("OnDragStop",  dlg.StopMovingOrSizing)
    if not dlg.SetBackdrop then Mixin(dlg, BackdropTemplateMixin) end
    dlg:SetBackdrop({
        bgFile   = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        edgeSize = 26,
        insets   = { left = 8, right = 8, top = 8, bottom = 8 },
    })
    dlg:SetBackdropColor(0.08, 0.05, 0.12, 0.98)

    local function AddField(label, yOff, w)
        local lbl = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        lbl:SetPoint("TOPLEFT", dlg, "TOPLEFT", 20, yOff)
        lbl:SetText(label)
        local box = CreateFrame("EditBox", nil, dlg, "InputBoxTemplate")
        box:SetSize(w or 280, 24)
        box:SetPoint("TOPLEFT", dlg, "TOPLEFT", 20, yOff - 20)
        box:SetAutoFocus(false)
        box:SetMaxLetters(60)
        return box
    end

    local titleBox = AddField("Raid Titel:",               -44)
    local dateBox  = AddField("Datum (z.B. 2026-04-20):",  -90)
    local timeBox  = AddField("Uhrzeit (z.B. 20:00):",    -136, 120)

    dateBox:SetText(date("%Y-%m-%d"))
    timeBox:SetText("20:00")

    local ok = CreateFrame("Button", nil, dlg, "UIPanelButtonTemplate")
    ok:SetSize(110, 26)
    ok:SetPoint("BOTTOMLEFT", dlg, "BOTTOMLEFT", 20, 16)
    ok:SetText("Erstellen")
    ok:SetScript("OnClick", function()
        local t = titleBox:GetText()
        if not t or t == "" then t = "Guild Raid" end
        RexGuild.Raids:Create(t, dateBox:GetText(), timeBox:GetText())
        dlg:Hide()
    end)

    local cancel = CreateFrame("Button", nil, dlg, "UIPanelButtonTemplate")
    cancel:SetSize(80, 26)
    cancel:SetPoint("BOTTOMRIGHT", dlg, "BOTTOMRIGHT", -20, 16)
    cancel:SetText("Abbrechen")
    cancel:SetScript("OnClick", function() dlg:Hide() end)

    self.createDialog = dlg
end
