-- ============================================================
--  RexGuild – UI/UI_Groups.lua
-- ============================================================

local RexGuild = _G["RexGuild"]
RexGuild.UI_Groups = {}
local UIG  = RexGuild.UI_Groups
local rows = {}

-- ────────────────────────────────────────────────────────────
-- ROLE ICONS (Original Blizzard)
-- ────────────────────────────────────────────────────────────
local ROLE_ICONS = {
    TANK = "|TInterface\\LFGFrame\\UI-LFG-ICON-PORTRAITROLES:20:20:0:0:64:64:0:19:22:41|t",
    HEAL = "|TInterface\\LFGFrame\\UI-LFG-ICON-PORTRAITROLES:20:20:0:0:64:64:20:39:1:20|t",
    DPS  = "|TInterface\\LFGFrame\\UI-LFG-ICON-PORTRAITROLES:20:20:0:0:64:64:20:39:22:41|t",
}

-- ────────────────────────────────────────────────────────────
-- HILFSFUNKTIONEN
-- ────────────────────────────────────────────────────────────
local function GetClassColor(class)
    local c = RAID_CLASS_COLORS[class]
    if not c then return "FFFFFF" end
    return string.format("%02X%02X%02X",
        math.floor(c.r * 255),
        math.floor(c.g * 255),
        math.floor(c.b * 255))
end

-- Frames sauber entfernen statt nur hiden
local function DestroyRows()
    for _, r in ipairs(rows) do
        if r then r:Hide() end
    end
    wipe(rows)
end

-- ────────────────────────────────────────────────────────────
-- INIT
-- ────────────────────────────────────────────────────────────
function UIG:Init(parent)
    if self.initialized then return end
    self.initialized = true
    self.parent = parent

    -- Titel-Eingabe
    local input = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
    input:SetSize(180, 24)
    input:SetPoint("TOPLEFT", 10, -40)
    input:SetText("M+ 10")
    input:SetAutoFocus(false)
    self.input = input

    -- Create-Button
    local create = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    create:SetSize(120, 24)
    create:SetPoint("LEFT", input, "RIGHT", 10, 0)
    create:SetText("Erstellen")
    create:SetScript("OnClick", function()
        local title = input:GetText()
        if title and title ~= "" then
            RexGuild.Groups:Create(title)
            UIG:Refresh()
        end
    end)

    -- Content-Container
    local content = CreateFrame("Frame", nil, parent)
    content:SetPoint("TOPLEFT", 10, -80)
    content:SetPoint("BOTTOMRIGHT", -10, 10)
    self.content = content

    self:Refresh()
end

-- ────────────────────────────────────────────────────────────
-- REFRESH  (FIX: kein Memory Leak, Accept/Decline Buttons)
-- ────────────────────────────────────────────────────────────
function UIG:Refresh()
    DestroyRows()

    if not self.content then return end

    local groups  = RexGuild.Groups:GetAll()
    local myName  = UnitName("player")
    local y       = 0

    for id, g in pairs(groups) do

        -- Höhe dynamisch: Header + je Member 22px + Buttons 28px
        local memberCount = 0
        for _ in pairs(g.members or {}) do memberCount = memberCount + 1 end
        local rowH = 36 + memberCount * 22 + 30

        -- Gruppen-Zeile
        local row = CreateFrame("Frame", nil, self.content, "BackdropTemplate")
        row:SetSize(520, rowH)
        row:SetPoint("TOPLEFT", 0, -y)
        if not row.SetBackdrop then Mixin(row, BackdropTemplateMixin) end
        row:SetBackdrop({
            bgFile  = "Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            edgeSize = 12,
            insets  = { left = 3, right = 3, top = 3, bottom = 3 },
        })
        row:SetBackdropBorderColor(0.3, 0.3, 0.3, 1)

        -- Gruppen-Titel
        local title = row:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOPLEFT", 10, -10)
        title:SetText((g.title or "Event") .. "  |cFFAAAAAA(Leader: " .. g.leader .. ")|r")

        -- Status-Badge
        local statusColor = g.status == "FULL" and "|cFFFF4444" or "|cFF00FF00"
        local statusText  = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        statusText:SetPoint("TOPRIGHT", -12, -12)
        statusText:SetText(statusColor .. (g.status or "OPEN") .. "|r")

        -- Members
        local offsetY = -34
        for name, m in pairs(g.members or {}) do
            local role     = m.role or "DPS"
            local icon     = ROLE_ICONS[role] or ""
            local color    = GetClassColor(m.class)
            local statusClr = m.status == "PENDING"  and "|cFFFFAA00"
                           or m.status == "ACCEPTED" and "|cFF00FF00"
                           or "|cFFFF4444"

            -- Member-Zeile Text
            local txt = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            txt:SetPoint("TOPLEFT", 12, offsetY)
            txt:SetText(
                icon .. " " ..
                statusClr .. "[" .. (m.status or "?") .. "]|r " ..
                "|cFF" .. color .. name .. "|r  " ..
                "|cFFFFFF00" .. (m.ilvl or 0) .. " ilvl|r" ..
                (m.score and m.score > 0 and ("  |cFF00CCFF" .. m.score .. "|r") or "")
            )

            -- ── Accept / Decline: nur für Leader, nur bei PENDING ──
            if g.leader == myName and m.status == "PENDING" then
                local acceptBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
                acceptBtn:SetSize(70, 20)
                acceptBtn:SetPoint("LEFT", txt, "RIGHT", 8, 0)
                acceptBtn:SetText("|cFF00FF00Annehmen|r")
                local capName = name  -- closure
                local capID   = id
                acceptBtn:SetScript("OnClick", function()
                    RexGuild.Groups:Respond(capID, capName, true)
                end)

                local declineBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
                declineBtn:SetSize(70, 20)
                declineBtn:SetPoint("LEFT", acceptBtn, "RIGHT", 4, 0)
                declineBtn:SetText("|cFFFF4444Ablehnen|r")
                declineBtn:SetScript("OnClick", function()
                    RexGuild.Groups:Respond(capID, capName, false)
                end)
            end

            offsetY = offsetY - 22
        end

        -- ── Join-Button (für Nicht-Leader) ─────────────────
        if g.leader ~= myName and g.status ~= "FULL" then
            local inGroup = g.members and g.members[myName] ~= nil
            if not inGroup then
                local join = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
                join:SetSize(80, 22)
                join:SetPoint("BOTTOMRIGHT", -10, 8)
                join:SetText("Anmelden")
                local capID = id
                join:SetScript("OnClick", function()
                    RexGuild.Groups:Join(capID)
                    UIG:Refresh()
                end)
            end
        end

        -- ── Delete-Button (nur Leader) ──────────────────────
        if g.leader == myName then
            local del = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
            del:SetSize(80, 22)
            del:SetPoint("BOTTOMRIGHT", -10, 8)
            del:SetText("Löschen")
            local capID = id
            del:SetScript("OnClick", function()
                RexGuild.Groups:Delete(capID)
                UIG:Refresh()
            end)
        end

        table.insert(rows, row)
        y = y + rowH + 8
    end
end
