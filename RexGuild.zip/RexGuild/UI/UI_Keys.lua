-- ============================================================
--  RexGuild – UI/UI_Keys.lua
--  Key-Übersicht: eigener Key oben, dann alle Gildenmitglieder
-- ============================================================

local RexGuild = _G["RexGuild"]
RexGuild.UI_Keys = {}
local UIK = RexGuild.UI_Keys

local dynamicRows = {}

-- ── GearScore / Item Level des Spielers ──────────────────────
local function GetItemLevel(unit)
    unit = unit or "player"
    local avg, equipped = GetAverageItemLevel and GetAverageItemLevel()
    return math.floor(equipped or avg or 0)
end

-- ── Farbe je Key-Level ────────────────────────────────────────
local function KeyColor(level)
    if not level then return "|cFFCCCCCC" end
    if level >= 20 then return "|cFFFF8000" end  -- Orange (Portail)
    if level >= 15 then return "|cFF00FF00" end  -- Grün
    if level >= 10 then return "|cFF00CCFF" end  -- Blau
    return "|cFFCCCCCC"                           -- Grau
end

-- ── Score-Farbe ───────────────────────────────────────────────
local function ScoreColor(score)
    if score >= 3000 then return "|cFFFF8000" end
    if score >= 2000 then return "|cFFAA44FF" end
    if score >= 1000 then return "|cFF0099FF" end
    return "|cFFCCCCCC"
end

function UIK:Init(parent)
    self.parent = parent

    -- ── Eigener Key: Highlight-Box oben ──────────────────────
    local myBox = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    myBox:SetPoint("TOPLEFT",  parent, "TOPLEFT",  10, -10)
    myBox:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -10, -10)
    myBox:SetHeight(64)
    myBox:SetBackdrop({
        bgFile   = "Interface\\ChatFrame\\ChatFrameBackground",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        edgeSize = 12,
        insets   = { left = 3, right = 3, top = 3, bottom = 3 },
    })
    myBox:SetBackdropColor(0.08, 0.04, 0.18, 1.0)
    myBox:SetBackdropBorderColor(0.6, 0.3, 1.0, 1.0)
    self.myBox = myBox

    local myLabel = myBox:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
    myLabel:SetPoint("LEFT", myBox, "LEFT", 12, 8)
    myLabel:SetText("Dein Key: wird geladen...")
    self.myLabel = myLabel

    local myDetails = myBox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    myDetails:SetPoint("LEFT", myBox, "LEFT", 12, -14)
    myDetails:SetText("")
    self.myDetails = myDetails

    -- Scan-Button direkt daneben
    local scanBtn = CreateFrame("Button", nil, myBox, "UIPanelButtonTemplate")
    scanBtn:SetSize(80, 22)
    scanBtn:SetPoint("RIGHT", myBox, "RIGHT", -10, 0)
    scanBtn:SetText("Scan Key")
    scanBtn:SetScript("OnClick", function()
        if RexGuild.Keys then RexGuild.Keys:ScanKey() end
    end)

    -- ── Trennlinie ────────────────────────────────────────────
    local sep = parent:CreateTexture(nil, "ARTWORK")
    sep:SetPoint("TOPLEFT",  parent, "TOPLEFT",  10, -82)
    sep:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -10, -82)
    sep:SetHeight(1)
    sep:SetColorTexture(0.4, 0.2, 0.8, 0.6)

    -- ── Spalten-Header ────────────────────────────────────────
    local hdr = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hdr:SetPoint("TOPLEFT", parent, "TOPLEFT", 12, -90)
    hdr:SetText("|cFF9999FFSpieler              Key        Dungeon                          GS     Score|r")

    -- ── Scroll für Gilden-Keys ────────────────────────────────
    local sf = CreateFrame("ScrollFrame", nil, parent, "UIPanelScrollFrameTemplate")
    sf:SetPoint("TOPLEFT",     parent, "TOPLEFT",     10,  -108)
    sf:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", -30, 10)
    self.scrollFrame = sf

    local content = CreateFrame("Frame", nil, sf)
    content:SetSize(sf:GetWidth() or 640, 1)
    sf:SetScrollChild(content)
    self.content = content

    UIK:Refresh()
end

function UIK:Refresh()
    -- ── Eigener Key ───────────────────────────────────────────
    if self.myLabel then
        local me   = RexGuild:GetMyName()
        local myK  = RexGuild.db.keys[me]
        local gs   = GetItemLevel("player")
        local score = (myK and myK.score) or 0

        if myK and myK.level then
            local col = KeyColor(myK.level)
            self.myLabel:SetText(string.format(
                "Dein Key:  %s+%d|r  %s",
                col, myK.level, myK.dungeon or "?"
            ))
        else
            self.myLabel:SetText("|cFFFF4444Kein Keystone im Bag|r")
        end

        self.myDetails:SetText(string.format(
            "Item Level: |cFFFFD700%d|r    Score: %s%d|r",
            gs, ScoreColor(score), score
        ))
    end

-- ── Gilden-Key-Liste ──────────────────────────────────────
if not self.content then return end

for _, r in ipairs(dynamicRows) do r:Hide() end
dynamicRows = {}

local keys  = RexGuild.Keys and RexGuild.Keys:GetAllKeys() or {}
local y     = 0
local ROW_H = 26
local me    = RexGuild:GetMyName()

for _, entry in ipairs(keys) do
    if entry.name ~= me then
        local d    = entry.data
        local col  = KeyColor(d.level)
        local scol = ScoreColor(d.score or 0)

        local row = CreateFrame("Frame", nil, self.content)
        row:SetSize(self.content:GetWidth() or 640, ROW_H)
        row:SetPoint("TOPLEFT", self.content, "TOPLEFT", 0, -y)

        -- Zebrastreifen
        if y % (ROW_H * 2) == 0 then
            local stripe = row:CreateTexture(nil, "BACKGROUND")
            stripe:SetAllPoints(row)
            stripe:SetColorTexture(1, 1, 1, 0.03)
        end

        -- 🔥 GS holen (NEU)
        local playerData = RexGuild.db.players and RexGuild.db.players[entry.name]
        local gs = playerData and playerData.gs or 0

        -- 🔥 LABEL (WICHTIG: nach GS definieren)
        local lbl = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        lbl:SetPoint("LEFT", row, "LEFT", 6, 0)

        lbl:SetText(string.format(
            "%-20s  %s+%2d|r  %-30s  |cFFFFD700%3d|r  %s%d|r",
            entry.name,
            col, d.level or 0,
            d.dungeon or "No key",
            gs,
            scol, d.score or 0
        ))

        table.insert(dynamicRows, row)
        y = y + ROW_H
    end
end

    if #keys == 0 or (#keys == 1 and RexGuild.db.keys[me]) then
        local empty = self.content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        empty:SetPoint("TOPLEFT", self.content, "TOPLEFT", 8, -10)
        empty:SetText("|cFFAAAAAA Noch keine Gildenmitglieder synchronisiert. Klicke Sync.|r")
        table.insert(dynamicRows, empty)
    end

    self.content:SetHeight(math.max(y, 10))
end
