-- ============================================================
--  RexGuild – UI/UI_Main.lua (FINAL CLEAN)
-- ============================================================

local RexGuild = _G["RexGuild"]
RexGuild.UI_Main = {}
local UI = RexGuild.UI_Main

local FRAME_W = 700
local FRAME_H = 500
local TABS = { "Keys", "Groups", "Raids" }

local frame, activeTab

-- ────────────────────────────────────────────────────────────
-- BUILD
-- ────────────────────────────────────────────────────────────
function UI:Build()
    if frame then return end

    frame = CreateFrame("Frame", "RexGuildMain", UIParent, "BackdropTemplate")
    frame:SetSize(FRAME_W, FRAME_H)
    frame:SetPoint("CENTER")
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:SetFrameStrata("HIGH")

    frame:SetBackdrop({
        bgFile   = "Interface\\ChatFrame\\ChatFrameBackground",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        edgeSize = 26,
        insets   = { left = 8, right = 8, top = 8, bottom = 8 },
    })
    frame:SetBackdropColor(0.05, 0.05, 0.08, 1)

    frame:Hide()

    -- TITLE
    local title = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
    title:SetPoint("TOP", 0, -16)
    title:SetText("|cFF9370DBRex|r|cFFFFFFFFGuild|r")

    -- CLOSE
    local closeBtn = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", -4, -4)
    closeBtn:SetScript("OnClick", function() frame:Hide() end)

    -- TABS
    UI.tabButtons = {}
    UI.tabContent = {}

    for i, name in ipairs(TABS) do
        local btn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
        btn:SetSize(120, 28)
        btn:SetPoint("TOPLEFT", 16 + (i - 1) * 128, -44)
        btn:SetText(name)
        btn:SetScript("OnClick", function() UI:ShowTab(i) end)
        UI.tabButtons[i] = btn
    end

    -- PANELS
    for i = 1, #TABS do
        local panel = CreateFrame("Frame", nil, frame, "BackdropTemplate")
        panel:SetPoint("TOPLEFT", 10, -80)
        panel:SetPoint("BOTTOMRIGHT", -10, 40)

        panel:SetBackdrop({
            bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            edgeSize = 12,
            insets = { left = 3, right = 3, top = 3, bottom = 3 },
        })

        panel:SetBackdropColor(0.03, 0.03, 0.06, 1)
        panel:Hide()

        UI.tabContent[i] = panel
    end

    -- ─────────────────────────────────────────────────────────
    -- ROLE BUTTONS (FIXED + HIGHLIGHT)
    -- ─────────────────────────────────────────────────────────

    local roleLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    roleLabel:SetPoint("BOTTOMLEFT", 16, 14)
    roleLabel:SetText("|cFFAAAAFFMeine Rolle:|r")

    local roles = {
        { id = "TANK", label = "Tank" },
        { id = "HEAL", label = "Heal" },
        { id = "DPS",  label = "DPS" },
    }

    UI.roleButtons = {}

    for i, r in ipairs(roles) do
        local btn = CreateFrame("Button", nil, frame, "BackdropTemplate")
        btn:SetSize(80, 22)
        btn:SetPoint("BOTTOMLEFT", 120 + (i - 1) * 86, 10)

        btn:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8" })
        btn:SetBackdropColor(0.1, 0.1, 0.1, 0.8)

        local txt = btn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        txt:SetPoint("CENTER")
        txt:SetText(r.label)

        UI.roleButtons[r.id] = btn

        btn:SetScript("OnClick", function()
            RexGuild:SetMyRole(r.id)

            -- Highlight
            for role, b in pairs(UI.roleButtons) do
                if role == r.id then
                    b:SetBackdropColor(0, 0.8, 0, 0.8)
                else
                    b:SetBackdropColor(0.1, 0.1, 0.1, 0.8)
                end
            end
        end)
    end

    -- SYNC BUTTON
    local syncBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    syncBtn:SetSize(80, 22)
    syncBtn:SetPoint("BOTTOMRIGHT", -16, 10)
    syncBtn:SetText("Sync")

    syncBtn:SetScript("OnClick", function()
        if RexGuild.Sync then RexGuild.Sync:Ping() end
    end)

    -- INIT SUB UIs
    if RexGuild.UI_Keys   then RexGuild.UI_Keys:Init(UI.tabContent[1]) end
    if RexGuild.UI_Groups then RexGuild.UI_Groups:Init(UI.tabContent[2]) end
    if RexGuild.UI_Raids  then RexGuild.UI_Raids:Init(UI.tabContent[3]) end

    UI:ShowTab(1)
end

-- ────────────────────────────────────────────────────────────
function UI:ShowTab(index)
    activeTab = index

    for i, panel in ipairs(UI.tabContent) do
        panel:SetShown(i == index)
    end

    UI:Refresh()
end

-- ────────────────────────────────────────────────────────────
function UI:Toggle()
    if not frame then UI:Build() end

    if frame:IsShown() then
        frame:Hide()
    else
        frame:Show()
        UI:Refresh()
    end
end

-- ────────────────────────────────────────────────────────────
function UI:Refresh()
    if not frame or not frame:IsShown() then return end

    if activeTab == 1 and RexGuild.UI_Keys   then RexGuild.UI_Keys:Refresh() end
    if activeTab == 2 and RexGuild.UI_Groups then RexGuild.UI_Groups:Refresh() end
    if activeTab == 3 and RexGuild.UI_Raids  then RexGuild.UI_Raids:Refresh() end
end