-- ============================================================
--  RexGuild – Groups.lua
-- ============================================================

local RexGuild = _G["RexGuild"]
RexGuild.Groups = {}
local Groups = RexGuild.Groups

local MAX_MEMBERS = 5

-- ────────────────────────────────────────────────────────────
-- SAFE DB
-- ────────────────────────────────────────────────────────────
local function EnsureDB()
    RexGuild.db = RexGuild.db or {}
    RexGuild.db.groups = RexGuild.db.groups or {}
end

-- ────────────────────────────────────────────────────────────
-- PLAYER DATA
-- ────────────────────────────────────────────────────────────
local function GetPlayerData()
    local role = RexGuild:GetMyRole()
    if role == "HEALER" then role = "HEAL" end
    if role == "DAMAGER" then role = "DPS" end

    local class = select(2, UnitClass("player"))

    local ilvl = 0
    if GetAverageItemLevel then
        local _, equipped = GetAverageItemLevel()
        ilvl = math.floor(equipped or 0)
    end

    return role, class, ilvl
end

-- ────────────────────────────────────────────────────────────
-- MEMBER COUNT
-- ────────────────────────────────────────────────────────────
function Groups:GetMemberCount(group)
    local c = 0
    for _, m in pairs(group.members or {}) do
        if m.status == "ACCEPTED" then
            c = c + 1
        end
    end
    return c
end

-- ────────────────────────────────────────────────────────────
-- CREATE
-- ────────────────────────────────────────────────────────────
function Groups:Create(title)
    EnsureDB()

    local player = UnitName("player")
    local role, class, ilvl = GetPlayerData()
    local id = player .. "-" .. time()

    RexGuild.db.groups[id] = {
        id      = id,
        leader  = player,
        title   = title or "Event",
        created = time(),
        status  = "OPEN",
        members = {
            [player] = {
                role   = role,
                class  = class,
                ilvl   = ilvl,
                status = "ACCEPTED"
            }
        }
    }

    if RexGuild.Sync then
        RexGuild.Sync:BroadcastGroup(RexGuild.db.groups[id])
    end
end

-- ────────────────────────────────────────────────────────────
-- JOIN
-- ────────────────────────────────────────────────────────────
function Groups:Join(groupID)
    EnsureDB()

    local player = UnitName("player")
    local group  = RexGuild.db.groups[groupID]
    if not group then return end
    if group.members[player] then return end
    if self:GetMemberCount(group) >= MAX_MEMBERS then return end

    local role, class, ilvl = GetPlayerData()

    group.members[player] = {
        role   = role,
        class  = class,
        ilvl   = ilvl,
        status = "PENDING"
    }

    if RexGuild.Sync then
        RexGuild.Sync:BroadcastGroup(group)
    end
end

-- ────────────────────────────────────────────────────────────
-- RESPOND (Accept / Decline)
-- ────────────────────────────────────────────────────────────
function Groups:Respond(groupID, playerName, accept)
    EnsureDB()

    local group = RexGuild.db.groups[groupID]
    if not group then return end
    if group.leader ~= UnitName("player") then
        print("Fehler: Nur der Leader kann antworten.")
        return
    end

    group.members = group.members or {}

    -- Member suchen (exakt oder fuzzy falls Realm fehlt)
    local member = group.members[playerName]
    if not member then
        for name, m in pairs(group.members) do
            if string.find(name, playerName, 1, true) then
                member     = m
                playerName = name
                break
            end
        end
    end

    if not member then
        print("Fehler: Member nicht gefunden:", playerName)
        return
    end

    if accept then
        if self:GetMemberCount(group) >= MAX_MEMBERS then
            print("Fehler: Gruppe bereits voll.")
            return
        end

        member.status = "ACCEPTED"

        -- Invite: Realm anhängen wenn noch nicht vorhanden
        local fullName = playerName
        if not string.find(playerName, "-", 1, true) then
            fullName = playerName .. "-" .. GetNormalizedRealmName()
        end

        if C_PartyInfo and C_PartyInfo.InviteUnit then
            C_PartyInfo.InviteUnit(fullName)
        else
            InviteUnit(fullName)
        end

        print("|cFF00FF00Einladung gesendet:|r " .. fullName)
    else
        group.members[playerName] = nil
        print("|cFFFF4444Abgelehnt:|r " .. playerName)
    end

    group.status = (self:GetMemberCount(group) >= MAX_MEMBERS) and "FULL" or "OPEN"

    if RexGuild.Sync then
        RexGuild.Sync:BroadcastGroup(group)
    end

    if RexGuild.UI_Groups then
        RexGuild.UI_Groups:Refresh()
    end
end

-- ────────────────────────────────────────────────────────────
-- DELETE
-- ────────────────────────────────────────────────────────────
function Groups:Delete(groupID)
    EnsureDB()

    local group = RexGuild.db.groups[groupID]
    if not group then return end
    if group.leader ~= UnitName("player") then return end

    RexGuild.db.groups[groupID] = nil

    if RexGuild.Sync then
        RexGuild.Sync:BroadcastGroup({ id = groupID, status = "DELETED" })
    end
end

-- ────────────────────────────────────────────────────────────
-- RECEIVE  (FIX: Sound auch wenn Fenster geschlossen)
-- ────────────────────────────────────────────────────────────
function Groups:ReceiveGroup(data)
    if not data or not data.id then return end
    EnsureDB()

    if data.status == "DELETED" then
        RexGuild.db.groups[data.id] = nil
        if RexGuild.UI_Groups then
            RexGuild.UI_Groups:Refresh()
        end
        return
    end

    local myName   = UnitName("player")
    local existing = RexGuild.db.groups[data.id]

    -- Sound: nur für den Leader, unabhängig ob UI offen oder zu
    -- Vergleich: leader ohne Realm vs UnitName ohne Realm
    local leaderShort = (data.leader or ""):match("^([^%-]+)") or data.leader or ""
    local myShort     = (myName or ""):match("^([^%-]+)") or myName or ""

    if leaderShort == myShort and data.members then
        for name, m in pairs(data.members) do
            if m.status == "PENDING" then
                local oldMember = existing
                    and existing.members
                    and existing.members[name]
                local oldStatus = oldMember and oldMember.status

                if oldStatus ~= "PENDING" then
                    -- Sicherer Sound der garantiert existiert
                    PlaySound(888) -- SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON = 888
                    print("|cFF00CCFFRexGuild:|r Neue Anmeldung von |cFFFFFF00" .. name .. "|r")
                end
            end
        end
    end

    RexGuild.db.groups[data.id] = data

    if RexGuild.UI_Groups and RexGuild.UI_Groups.Refresh then
        RexGuild.UI_Groups:Refresh()
    end
end

-- ────────────────────────────────────────────────────────────
-- GET ALL
-- ────────────────────────────────────────────────────────────
function Groups:GetAll()
    EnsureDB()
    return RexGuild.db.groups
end
