-- ============================================================
--  RexGuild – Modules/Sync.lua (FINAL VERSION)
--  ✔ Self-filter
--  ✔ UI Update Trigger
--  ✔ Throttle (Anti Spam)
--  ✔ Debug Mode
--  ✔ Safe Deserialize
-- ============================================================

local RexGuild = _G["RexGuild"]
RexGuild.Sync = {}
local Sync = RexGuild.Sync

local AceSerializer = LibStub("AceSerializer-3.0")
local CHANNEL = "GUILD"
local PREFIX  = "RexGuild"

-- 🔥 Anti-Spam Throttle
local lastSend = 0
local SEND_DELAY = 1 -- Sekunden

-- Message type constants
local MSG = {
    KEY      = "K",
    GROUP    = "G",
    RAID     = "R",
    RSVP     = "V",
    ROLE     = "L",
    PING     = "P",
}

-- ── Internal send helper ─────────────────────────────────────
local function Send(msgType, payload)

    -- 🔥 Throttle Schutz
    if GetTime() - lastSend < SEND_DELAY then return end
    lastSend = GetTime()

    local data = { t = msgType, d = payload }
    local serialized = AceSerializer:Serialize(data)

    RexGuild:SendCommMessage(PREFIX, serialized, CHANNEL)

    -- 🔍 Debug
    if RexGuild.debug then
        print("|cff00ff00[RexGuild Sync]|r Sent:", msgType)
    end
end

-- ── Broadcast functions ──────────────────────────────────────
function Sync:BroadcastMyKey()
    local name = RexGuild:GetMyName()
    local key  = RexGuild.db.keys[name]
    if not key then return end

    Send(MSG.KEY, { player = name, key = key })
end

function Sync:BroadcastGroup(group)
    if not group then return end
    Send(MSG.GROUP, group)
end

function Sync:BroadcastRaid(raid)
    if not raid then return end
    Send(MSG.RAID, raid)
end

function Sync:BroadcastRaidRSVP(raidID, playerName, status)
    if not raidID then return end

    local role = RexGuild:GetMyRole()
    Send(MSG.RSVP, {
        raidID = raidID,
        player = playerName,
        status = status,
        role   = role
    })
end

function Sync:BroadcastMyRole()
    local name = RexGuild:GetMyName()
    local role = RexGuild:GetMyRole()
    local gs   = RexGuild:UpdateMyGS() -- 🔥 NEU

    Send(MSG.ROLE, {
        player = name,
        role   = role,
        gs     = gs -- 🔥 NEU
    })
end

-- Request all guild members to re-broadcast their data
function Sync:Ping()
    Send(MSG.PING, {})
end

-- ── Receive and dispatch ─────────────────────────────────────
function Sync:HandleIncoming(rawMessage, sender)

    -- ❌ Eigene Messages ignorieren
    if sender == RexGuild:GetMyName() then return end

    local ok, data = AceSerializer:Deserialize(rawMessage)
    if not ok or not data or not data.t then return end

    local t = data.t
    local d = data.d

    -- 🔍 Debug
    if RexGuild.debug then
        print("|cff00ff00[RexGuild Sync]|r Received:", t, "from", sender)
    end

    -- ── Dispatch ────────────────────────────────────────────
    if t == MSG.KEY then
        if d and d.player and d.key then
            if RexGuild.Keys then
                RexGuild.Keys:ReceiveKey(d.player, d.key)
            end
        end

    elseif t == MSG.GROUP then
        if RexGuild.Groups then
            RexGuild.Groups:ReceiveGroup(d)
        end

    elseif t == MSG.RAID then
        if RexGuild.Raids then
            RexGuild.Raids:ReceiveRaid(d)
        end

    elseif t == MSG.RSVP then
        if d and d.raidID then
            if RexGuild.Raids then
                RexGuild.Raids:ReceiveRSVP(
                    d.raidID,
                    d.player,
                    d.status,
                    d.role
                )
            end
        end

    elseif t == MSG.ROLE then
    if d and d.player then

        -- 🔥 REALM FIX (DAS IST DER WICHTIGE TEIL)
        local short = d.player:match("^([^%-]+)") or d.player

        -- 🔥 Rolle speichern
        RexGuild.db.roles[short] = d.role

        -- 🔥 GS speichern
        RexGuild.db.players = RexGuild.db.players or {}
        RexGuild.db.players[short] = RexGuild.db.players[short] or {}
        RexGuild.db.players[short].gs = d.gs or 0
    end

    elseif t == MSG.PING then
    C_Timer.After(math.random(1, 3), function()

        -- 🔥 GS sicher aktualisieren
        RexGuild:UpdateMyGS()

        -- 🔥 dann senden
        Sync:BroadcastMyKey()
        Sync:BroadcastMyRole()

    end)
end

    -- 🔥 ULTRA WICHTIG → UI UPDATE
    if RexGuild.SendMessage then
        RexGuild:SendMessage("RG_UPDATE")
    end
end