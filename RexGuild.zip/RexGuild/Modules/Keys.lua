-- ============================================================
--  RexGuild – Modules/Keys.lua
--  Midnight / TWW kompatibel
--  Parst lokalisierten Keystone-Link: [Schlüsselstein: Name (Level)]
-- ============================================================

local RexGuild = _G["RexGuild"]
RexGuild.Keys = {}
local Keys = RexGuild.Keys

local KEYSTONE_ITEM_ID = 180653

-- ── Bag-Suche ────────────────────────────────────────────────
local function FindKeystoneInBags()
    for bag = 0, NUM_BAG_SLOTS or 4 do
        for slot = 1, (C_Container.GetContainerNumSlots(bag) or 0) do
            local info = C_Container.GetContainerItemInfo(bag, slot)
            if info and info.itemID == KEYSTONE_ITEM_ID then
                return bag, slot
            end
        end
    end
    return nil, nil
end

-- ── Link parsen ───────────────────────────────────────────────
-- Midnight liefert: [Schlüsselstein: Grube von Saron (6)]
-- Wir lesen Name + Level direkt aus dem lokalisierten String.
local function ParseKeystoneLink(itemLink)
    if not itemLink then return nil, nil end

    -- Midnight-Format (lokalisiert): [xxx: DUNGEONNAME (LEVEL)]
    local dungeonName, level = itemLink:match("%[.-:%s*(.-)%s*%((%d+)%)%]")
    if dungeonName and level then
        return dungeonName:gsub("^%s+", ""):gsub("%s+$", ""), tonumber(level)
    end

    -- Fallback: alter |Hitem:...|h Link
    local itemString = itemLink:match("|Hitem:(.-)|h")
    if itemString then
        local parts = {}
        for p in itemString:gmatch("[^:]+") do
            table.insert(parts, tonumber(p) or 0)
        end
        local mapID, lvl
        for i = #parts, 2, -1 do
            local v = parts[i]
            if v and v > 0 and v < 1000 and not mapID then mapID = v
            elseif v and v > 0 and v <= 30 and mapID then lvl = v; break end
        end
        -- mapID → Name über DUNGEON_NAMES wäre hier nötig, aber Midnight braucht das nicht
        return ("Dungeon #" .. (mapID or "?")), lvl
    end

    return nil, nil
end

-- ── M+ Score lesen ───────────────────────────────────────────
local function GetMyScore()
    if C_PlayerInfo and C_PlayerInfo.GetPlayerMythicPlusRatingSummary then
        local summary = C_PlayerInfo.GetPlayerMythicPlusRatingSummary("player")
        if summary and summary.currentSeasonScore then
            return math.floor(summary.currentSeasonScore)
        end
    end
    if C_MythicPlus and C_MythicPlus.GetCurrentSeasonBestForPlayer then
        local score = C_MythicPlus.GetCurrentSeasonBestForPlayer()
        if score then return math.floor(score) end
    end
    return 0
end

-- ── Key scannen ───────────────────────────────────────────────
function Keys:ScanKey()
    local name     = RexGuild:GetMyName()
    local existing = RexGuild.db.keys[name] or {}
    local score    = GetMyScore()

    local bag, slot = FindKeystoneInBags()
    if not bag then
        RexGuild.db.keys[name] = {
            dungeon = nil, level = nil,
            score   = score,
            updated = time(),
        }
        if RexGuild.UI_Keys then RexGuild.UI_Keys:Refresh() end
        return
    end

    local itemLink        = C_Container.GetContainerItemLink(bag, slot)
    local dungeon, level  = ParseKeystoneLink(itemLink)

    if not level then
        print("|cFFFFAA00RexGuild Debug:|r Parsing fehlgeschlagen für: " .. tostring(itemLink))
    end

    RexGuild.db.keys[name] = {
        dungeon = dungeon or "Unbekannt",
        level   = level,
        score   = score,
        updated = time(),
    }

    if RexGuild.UI_Keys then RexGuild.UI_Keys:Refresh() end
end

-- ── Empfang via Sync ─────────────────────────────────────────
function Keys:ReceiveKey(sender, data)
    if not sender or not data then return end
    RexGuild.db.keys[sender] = {
        dungeon = data.dungeon,
        level   = data.level,
        score   = data.score or 0,
        updated = time(),
    }
    if RexGuild.UI_Keys then RexGuild.UI_Keys:Refresh() end
end

function Keys:GetKey(playerName)
    return RexGuild.db.keys[playerName]
end

function Keys:GetAllKeys()
    local list = {}
    for name, data in pairs(RexGuild.db.keys) do
        if data.level then
            table.insert(list, { name = name, data = data })
        end
    end
    table.sort(list, function(a, b)
        return (a.data.level or 0) > (b.data.level or 0)
    end)
    return list
end

function Keys:FormatKey(playerName)
    local k = RexGuild.db.keys[playerName]
    if not k or not k.level then return playerName .. ": Kein Key" end
    return string.format("%s: +%d %s (Score: %d)",
        playerName, k.level, k.dungeon or "?", k.score or 0)
end
