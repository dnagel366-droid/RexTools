-- ============================================================
--  RexGuild – Modules/Raids.lua
-- ============================================================

local RexGuild = _G["RexGuild"]
RexGuild.Raids = {}
local Raids = RexGuild.Raids

local RSVP = { YES = "YES", NO = "NO", LATE = "LATE" }

-- ────────────────────────────────────────────────────────────
-- CREATE
-- ────────────────────────────────────────────────────────────
function Raids:Create(title, dateStr, timeStr, maxSize, note)
    local organizer = RexGuild:GetMyName()
    local id = string.format("raid-%s-%d", organizer, time())

    local raid = {
        id        = id,
        title     = title or "Guild Raid",
        date      = dateStr or "",
        time      = timeStr or "",
        maxSize   = maxSize or 20,
        note      = note or "",
        organizer = organizer,
        rsvp      = {},
        created   = time(),
    }

    raid.rsvp[organizer] = {
        status = RSVP.YES,
        role   = RexGuild:GetMyRole(),
    }

    RexGuild.db.raids[id] = raid

    if RexGuild.Sync then RexGuild.Sync:BroadcastRaid(raid) end
    if RexGuild.UI_Raids then RexGuild.UI_Raids:Refresh() end
    return id
end

-- ────────────────────────────────────────────────────────────
-- RSVP
-- ────────────────────────────────────────────────────────────
function Raids:SetRSVP(raidID, status)
    local raid = RexGuild.db.raids[raidID]
    if not raid then return end

    local name = RexGuild:GetMyName()
    raid.rsvp[name] = {
        status = status,
        role   = RexGuild:GetMyRole(),
    }

    if RexGuild.Sync then RexGuild.Sync:BroadcastRaidRSVP(raidID, name, status) end
    if RexGuild.UI_Raids then RexGuild.UI_Raids:Refresh() end
end

-- ────────────────────────────────────────────────────────────
-- ROLE UPDATE
-- ────────────────────────────────────────────────────────────
function Raids:UpdateMyRole(raidID)
    local raid = RexGuild.db.raids[raidID]
    if not raid then return end

    local name = RexGuild:GetMyName()
    local entry = raid.rsvp[name]
    if not entry then return end

    local newRole = RexGuild:GetMyRole()
    if entry.role == newRole then return end

    entry.role = newRole

    if RexGuild.Sync then
        RexGuild.Sync:BroadcastRaidRSVP(raidID, name, entry.status, newRole)
    end

    if RexGuild.UI_Raids then RexGuild.UI_Raids:Refresh() end
end

-- ────────────────────────────────────────────────────────────
-- DELETE
-- ────────────────────────────────────────────────────────────
function Raids:Delete(raidID)
    local raid = RexGuild.db.raids[raidID]
    if not raid then return end

    local myName  = RexGuild:GetMyName()
    local myShort = myName:match("^([^%-]+)") or myName
    local orgShort = (raid.organizer or ""):match("^([^%-]+)") or raid.organizer or ""

    if myShort ~= orgShort then
        print("|cFFFF4444RexGuild:|r Nur der Organizer kann diesen Raid löschen.")
        return
    end

    RexGuild.db.raids[raidID] = nil

    if RexGuild.Sync then
        RexGuild.Sync:BroadcastRaid({ id = raidID, deleted = true })
    end
    if RexGuild.UI_Raids then RexGuild.UI_Raids:Refresh() end
end

-- ────────────────────────────────────────────────────────────
-- INVITE ALL
-- ────────────────────────────────────────────────────────────
function Raids:InviteAll(raidID)
    local raid = RexGuild.db.raids[raidID]
    if not raid then return end

    local myName  = RexGuild:GetMyName()
    local myShort = myName:match("^([^%-]+)") or myName
    local orgShort = (raid.organizer or ""):match("^([^%-]+)") or raid.organizer or ""

    if myShort ~= orgShort then
        print("|cFFFF4444RexGuild:|r Nur der Organizer kann Einladungen senden.")
        return
    end

    local realm   = GetNormalizedRealmName()
    local invited = 0

    for name, entry in pairs(raid.rsvp) do
        if entry.status == RSVP.YES or entry.status == RSVP.LATE then
            local nameShort = name:match("^([^%-]+)") or name
            if nameShort ~= myShort then
                local fullName = name
                if not name:find("-", 1, true) then
                    fullName = name .. "-" .. realm
                end

                C_Timer.After(invited * 0.5, function()
                    if C_PartyInfo and C_PartyInfo.InviteUnit then
                        C_PartyInfo.InviteUnit(fullName)
                    else
                        InviteUnit(fullName)
                    end
                    print("|cFF00FF00RexGuild:|r Einladung gesendet an " .. fullName)
                end)

                invited = invited + 1
            end
        end
    end
end

-- ────────────────────────────────────────────────────────────
-- RECEIVE RAID
-- ────────────────────────────────────────────────────────────
function Raids:ReceiveRaid(data)
    if not data or not data.id then return end

    if data.deleted then
        RexGuild.db.raids[data.id] = nil
        if RexGuild.UI_Raids then RexGuild.UI_Raids:Refresh() end
        return
    end

    RexGuild.db.raids[data.id] = data
    if RexGuild.UI_Raids then RexGuild.UI_Raids:Refresh() end
end

-- ────────────────────────────────────────────────────────────
-- RECEIVE RSVP
-- ────────────────────────────────────────────────────────────
function Raids:ReceiveRSVP(raidID, playerName, status, role)
    local raid = RexGuild.db.raids[raidID]
    if not raid then return end

    local myName   = RexGuild:GetMyName()
    local myShort  = myName:match("^([^%-]+)") or myName
    local orgShort = (raid.organizer or ""):match("^([^%-]+)") or raid.organizer or ""

    local oldEntry = raid.rsvp[playerName]
    local oldStatus = oldEntry and oldEntry.status

    raid.rsvp[playerName] = {
        status = status,
        role   = role or "DAMAGER",
    }

    if myShort == orgShort and oldStatus ~= status then
        PlaySound(888)
    end

    if RexGuild.UI_Raids then RexGuild.UI_Raids:Refresh() end
end

-- ────────────────────────────────────────────────────────────
-- HELPERS
-- ────────────────────────────────────────────────────────────
function Raids:GetUpcoming()
    local list = {}
    local now = time()

    for id, raid in pairs(RexGuild.db.raids or {}) do
        local day, month, year = raid.date and raid.date:match("(%d+)%.(%d+)%.(%d+)")
        local hour, min = raid.time and raid.time:match("(%d+):(%d+)")

        if day and month and year and hour and min then
            local raidTime = time({
                year = tonumber(year),
                month = tonumber(month),
                day = tonumber(day),
                hour = tonumber(hour),
                min = tonumber(min),
                sec = 0
            })

            if now < (raidTime + 10800) then
                table.insert(list, raid)
            else
                RexGuild.db.raids[id] = nil
            end
        else
            table.insert(list, raid)
        end
    end

    table.sort(list, function(a, b)
        return (a.created or 0) > (b.created or 0)
    end)

    return list
end

function Raids:GetRosterSummary(raidID)
    local raid = RexGuild.db.raids[raidID]
    if not raid then return {} end

    local s = { yes = 0, no = 0, late = 0, tanks = 0, healers = 0, dps = 0 }

    for _, entry in pairs(raid.rsvp) do
        if entry.status == RSVP.YES  then s.yes  = s.yes  + 1 end
        if entry.status == RSVP.NO   then s.no   = s.no   + 1 end
        if entry.status == RSVP.LATE then s.late = s.late + 1 end

        if entry.status ~= RSVP.NO then
            local role = entry.role

            if role == "TANK" then s.tanks = s.tanks + 1 end
            if role == "HEAL" or role == "HEALER" then s.healers = s.healers + 1 end
            if role == "DPS" or role == "DAMAGER" then s.dps = s.dps + 1 end
        end
    end

    return s
end